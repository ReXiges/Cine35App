package cine35app.esteb.cine35app;

public class Rate {

    private int calificacion;

    public Rate(int calificacion) {
        this.calificacion = calificacion;
    }

    public int getCalificacion() {
        return calificacion;
    }

    public void setCalificacion(int calificacion) {
        this.calificacion = calificacion;
    }
}
