public class Actor extends Persona {
    public Actor(String name, String lastName, String date, String nation) {
        super(name, lastName, date, nation);
    }
}
