public class Director extends Persona {
    public Director(String name, String lastName, String date, String nation) {
        super(name, lastName, date, nation);
    }
}
